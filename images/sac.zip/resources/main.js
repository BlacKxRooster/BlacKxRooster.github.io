body {
  background-color: rgb(255, 199, 64);
  font-family: "Open Sans", Arial;
}

form {
  line-height: 27px;
}

h2 {
  font-size: 20px;
}

input[type="text"], input[type="number"] {
  min-height: 15px;
  border-radius: 5px;
  border:1px solid #cccccc;
}

input[type="radio"] {
  margin-left: 12px;
}

#main {
  background-color: rgba(255,255,255,0.8);
  text-align: center;
  height: 80vh;
  border-radius: 15px;
  margin: 2% 10%;
  overflow: auto;
}

#story {
  padding: 0 3%;
}

#top {
  background-color: rgb(255, 255, 255);
  margin: 2% 10%;
  border-radius: 15px;
}

#top img {
  display: block;
  width: 35%;
  margin: 0 auto;
}

.italics {
  font-style: italic;
}

.word {
  font-weight: bold;
  text-decoration: underline;
}
